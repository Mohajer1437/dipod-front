import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const filePath = path.join(process.cwd(), 'data', 'posts.json');

function readPosts() {
  return JSON.parse(fs.readFileSync(filePath, 'utf-8')).posts || [];
}
function writePosts(posts: any[]) {
  fs.writeFileSync(filePath, JSON.stringify({ posts }, null, 2));
}

export async function GET() {
  return NextResponse.json(readPosts());
}

export async function POST(req: NextRequest) {
  const newPost = await req.json();
  const posts = readPosts();

  newPost.id = posts.length ? posts[posts.length - 1].id + 1 : 1;
  newPost.createdAt = new Date().toISOString();

  posts.push(newPost);
  writePosts(posts);
  return NextResponse.json(newPost);
}

export async function PUT(req: NextRequest) {
  const updatePost = await req.json();
  const posts = readPosts();
  const index = posts.findIndex((p) => p.id === updatePost.id);
  if (index === -1) return NextResponse.json({ error: 'Post not found' }, { status: 404 });

  posts[index] = { ...posts[index], ...updatePost };
  writePosts(posts);
  return NextResponse.json(posts[index]);
}

export async function DELETE(req: NextRequest) {
  const { id } = await req.json();
  const posts = readPosts().filter((p) => p.id !== id);
  writePosts(posts);
  return NextResponse.json({ message: 'Deleted' });
}
